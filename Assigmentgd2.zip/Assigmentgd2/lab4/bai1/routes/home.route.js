import express from "express";
import { Post } from '../app/models/Post.js';  // ✅ Đúng  // Default import
// Import đúng cách

const router = express.Router();

router.get("/", async (req, res) => {
    try {
        const posts = await Post.find().lean(); // Dùng `.lean()` để trả về JSON thuần

        console.log("Dữ liệu bài viết:", Array.isArray(posts) ? "Là mảng ✅" : "Không phải mảng ❌", posts);

        res.render("home", { posts });
    } catch (error) {
        console.error("Lỗi khi lấy danh sách bài viết:", error);
        res.status(500).send("Lỗi server");
    }
});


export default router;
