import express from "express";
import User from "../app/models/User.js"; // Đảm bảo đường dẫn đúng
import jwt from "jsonwebtoken";
import { randomBytes, pbkdf2Sync } from "crypto";
import authMiddleware from '../app/middleware/auth.js';  // Điều chỉnh theo đúng đường dẫn tới auth.js


const router = express.Router();

// 🟢 [GET] Trang chính của User
router.get("/profile", (req, res) => {
    res.render("user/profile", { title: "Hồ sơ" });
});

// 🟢 Route để hiển thị thông tin người dùng
router.get('/profile', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.id;  // Lấy ID của user từ middleware xác thực
        const user = await User.findById(userId).select("-password -salt"); // Ẩn mật khẩu

        if (!user) {
            return res.status(404).send("Không tìm thấy người dùng");
        }

        res.render('user/profile', { 
            title: "Hồ sơ cá nhân",
            user 
        });
    } catch (err) {
        console.error("Lỗi khi lấy hồ sơ người dùng:", err);
        res.status(500).send("Lỗi server");
    }
});


// 🟢 [GET] Hiển thị form đăng ký
router.get("/register", (req, res) => {
    res.render("user/register", { title: "Đăng Ký" });  
});

// 🟢 [POST] Xử lý đăng ký
router.post("/register", async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).send("Vui lòng nhập đầy đủ thông tin!");
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
        return res.status(400).send("Email đã được sử dụng!");
    }

    // Tạo salt ngẫu nhiên
    const salt = randomBytes(16).toString("hex");

    // Hash mật khẩu với salt
    const hashedPassword = pbkdf2Sync(password, salt, 1000, 64, "sha256").toString("hex");

    // Tạo user mới
    const newUser = new User({
        username,
        email,  // ✅ Lưu email vào database
        password: hashedPassword,
        salt,
    });

    await newUser.save();
    res.send("Đăng ký thành công!");
});


// 🟢 [GET] Hiển thị form đăng nhập
router.get("/login", (req, res) => {
    res.render("user/login", { title: "Đăng Nhập" });  
});

// 🟢 [POST] Xử lý đăng nhập
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    try {
        // Tìm người dùng theo email
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({ message: "Sai tài khoản hoặc mật khẩu" });
        }

        // Hash lại mật khẩu nhập vào với salt đã lưu
        const hashedPassword = pbkdf2Sync(password, user.salt, 1000, 64, "sha256").toString("hex");

        // Kiểm tra mật khẩu
        if (hashedPassword !== user.password) {
            return res.status(400).json({ message: "Sai tài khoản hoặc mật khẩu" });
        }

        // Tạo token JWT
        const token = jwt.sign(
            { id: user._id, username: user.username },
            process.env.JWT_SECRET || 'secret',  // Use environment variable for secret
            { expiresIn: '1h' }
        );

        // Lưu token vào cookie
        res.cookie("token", token, { httpOnly: true, secure: process.env.NODE_ENV === 'production' });  // Use `secure: true` in production
        res.redirect("/");  // Redirect after successful login
    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({ message: "Đã xảy ra lỗi, vui lòng thử lại!" });
    }
});
// 🟢 [GET] Đăng xuất (Xóa token)
router.get("/logout", (req, res) => {
    res.clearCookie("token");  // Xóa cookie token
    res.redirect("/user/login");  // Chuyển hướng về trang đăng nhập
});
// Route để render trang hồ sơ người dùng
router.get('/profile', authMiddleware, async (req, res) => {
    try {
        const userId = req.session.userId || req.user.id;
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).send('User not found');
        }

        res.render('profile', {
            name: user.name,
            email: user.email,
            joinDate: user.joinDate.toLocaleDateString(),
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

export default router;
