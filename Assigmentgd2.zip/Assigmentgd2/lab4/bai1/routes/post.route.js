import express from 'express';
import multer from 'multer';
import path from 'path';
import { Post, createPost, getPostById, updatePostById, deletePostById } from '../app/models/Post.js';

const router = express.Router();

// Cấu hình multer để upload file ảnh
const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage });

// 🔍 Route: Tìm kiếm bài viết theo tiêu đề
router.get('/search', async (req, res) => {
    try {
        const searchQuery = req.query.q || ''; // Lấy từ khóa tìm kiếm
        console.log("🔍 Từ khóa tìm kiếm:", searchQuery); // Debug

        // Tìm kiếm bài viết trong MongoDB theo tiêu đề
        const posts = await Post.find({
            title: { $regex: searchQuery, $options: 'i' } 
        }).lean();

        console.log("📌 Kết quả tìm thấy:", posts); // Debug

        res.render('post/search', { posts, searchQuery });
    } catch (error) {
        console.error("❌ Lỗi khi tìm kiếm:", error);
        res.status(500).send('Lỗi khi tìm kiếm bài viết');
    }
});



// 🏠 Route: Hiển thị danh sách bài viết
router.get('/', async (req, res) => {
    try {
        const posts = await Post.find().lean();
        res.render('post/post', { posts });
    } catch (error) {
        console.error("Lỗi khi tải danh sách bài viết:", error);
        res.status(500).send('Error loading posts');
    }
});

// 📝 Route: Hiển thị form tạo bài viết
router.get('/create', (req, res) => {
    res.render('post/create', { title: "Tạo bài viết" });
});

// 📝 Route: Xử lý tạo bài viết mới
router.post('/create', upload.single('image'), async (req, res) => {
    try {
        const { title, content, author } = req.body;
        const imageUrl = req.file ? `/uploads/${req.file.filename}` : '';
        await createPost({ title, content, author, imageUrl });
        res.redirect('/post');
    } catch (error) {
        console.error("Lỗi khi tạo bài viết:", error);
        res.status(500).send('Error saving post');
    }
});

// 🔍 Route: Xem chi tiết bài viết
router.get("/:id", async (req, res) => {
    try {
        const post = await getPostById(req.params.id);
        if (!post) {
            return res.status(404).send("Bài viết không tồn tại");
        }
        res.render("post/detail", { post: post.toObject() });
    } catch (error) {
        console.error("Lỗi khi tải bài viết:", error);
        res.status(500).send("Lỗi khi tải bài viết");
    }
});

// 🖊️ Route: Hiển thị form chỉnh sửa bài viết
router.get('/edit/:id', async (req, res) => {
    try {
        const post = await getPostById(req.params.id);
        if (!post) {
            return res.status(404).send('Bài viết không tồn tại');
        }
        res.render('post/edit', { post: post.toObject() });
    } catch (error) {
        console.error('Lỗi khi tải trang chỉnh sửa:', error);
        res.status(500).send('Lỗi server');
    }
});

// ✏️ Route: Cập nhật bài viết
router.post('/edit/:id', async (req, res) => {
    try {
        const { title, content, author, imageUrl } = req.body;
        await updatePostById(req.params.id, { title, content, author, imageUrl });
        res.redirect('/post');
    } catch (error) {
        console.error('Lỗi khi cập nhật bài viết:', error);
        res.status(500).send('Lỗi server');
    }
});

// 🗑️ Route: Xóa bài viết
router.post('/delete', async (req, res) => {
    try {
        const { _id } = req.body;
        await deletePostById(_id);
        res.redirect('/post');
    } catch (error) {
        console.error('Lỗi khi xóa bài viết:', error);
        res.status(500).send('Lỗi khi xóa bài viết');
    }
});

export default router;
