import express from "express";
import { engine } from "express-handlebars";
import path from "path";
import { fileURLToPath } from "url";
import connectDB from "./config/db.js"; 
import userRoutes from "./routes/user.route.js"; 
import indexRoutes from "./routes/home.route.js";   // Đảm bảo đường dẫn đúng
import postRoutes from "./routes/post.route.js";  // Đảm bảo đường dẫn đúng
import cookieParser from "cookie-parser";
import authMiddleware from "./app/middleware/auth.js";

const app = express();
const port = 3000;

// Kết nối MongoDB
connectDB();

// Cấu hình __dirname với ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Cấu hình Handlebars
app.engine(
    "handlebars",
    engine({
        defaultLayout: "main",
        layoutsDir: path.join(__dirname, "views", "layouts"),
        partialsDir: path.join(__dirname, "views", "partials"),
    })
);

app.set("view engine", "handlebars");
app.set("views", path.join(__dirname, "views")); // Đảm bảo Handlebars tìm đúng thư mục views

// Middleware
app.use(express.json()); // Xử lý JSON từ request body
app.use(express.urlencoded({ extended: true })); // Xử lý dữ liệu từ form HTML
app.use(cookieParser());
app.use(authMiddleware); // Thêm middleware xác thực JWT

// Cấu hình tài nguyên tĩnh
app.use(express.static(path.join(__dirname, "public")));
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));

// Routes
app.use("/", indexRoutes); 
app.use("/user", userRoutes);  // ✅ Thêm routes cho User
app.use("/post", postRoutes);  // ✅ Thêm routes cho Post

app.get("/about", (req, res) => {
    res.render("about", { title: "Giới Thiệu" });
});

// Start server
app.listen(port, () => {
    console.log(`🚀 Server is running at http://localhost:${port}`);
});
