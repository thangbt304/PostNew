import mongoose from 'mongoose';

const PostSchema = new mongoose.Schema({
    title: String,
    content: String,
    author: String,
    imageUrl: String
}, { timestamps: true });

const Post = mongoose.model('Post', PostSchema);

// Phương thức CRUD cho Post
const createPost = async (data) => {
    const post = new Post(data);
    return await post.save();
};

const getPostById = async (id) => {
    if (!mongoose.Types.ObjectId.isValid(id)) {
        throw new Error("ID không hợp lệ");
    }
    return await Post.findById(id);
};

const updatePostById = async (id, data) => {
    return await Post.findByIdAndUpdate(id, data, { new: true });
};

const deletePostById = async (id) => {
    return await Post.findByIdAndDelete(id);
};

// Xuất theo chuẩn ES Module
export { Post, createPost, getPostById, updatePostById, deletePostById };
