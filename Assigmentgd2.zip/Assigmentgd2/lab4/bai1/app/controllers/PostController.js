const posts = [
    { id: 1, title: "Bài viết 1", content: "Nội dung bài viết 1" },
    { id: 2, title: "Bài viết 2", content: "Nội dung bài viết 2" },
];

// Hiển thị danh sách bài viết
export const getAllPosts = (req, res) => {
    res.render("post", { title: "Danh Sách Bài Viết", posts });
};

// Hiển thị chi tiết bài viết theo ID
export const getPostById = (req, res) => {
    const postId = parseInt(req.params.id, 10);
    const post = posts.find((p) => p.id === postId);

    if (!post) {
        return res.status(404).send("<h1>Bài viết không tồn tại!</h1>");
    }

    res.render("postDetail", { title: post.title, post });
};
