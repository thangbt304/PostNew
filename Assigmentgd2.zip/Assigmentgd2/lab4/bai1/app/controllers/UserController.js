import User from "../models/User.js";
import bcrypt from "bcrypt";

// Hiển thị form đăng ký
export const showRegisterForm = (req, res) => {
    res.render("register", { title: "Đăng Ký" });
};

// Xử lý đăng ký
export const registerUser = async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();

        res.redirect("/user/login"); // Chuyển hướng đến trang đăng nhập
    } catch (error) {
        res.status(500).send("Lỗi đăng ký");
    }
};

// Hiển thị form đăng nhập
export const showLoginForm = (req, res) => {
    res.render("/user/user", { title: "Đăng Nhập" });
};

// Xử lý đăng nhập
export const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(400).send("Sai email hoặc mật khẩu");
        }

        res.redirect("/post"); // Chuyển hướng sau khi đăng nhập thành công
    } catch (error) {
        res.status(500).send("Lỗi đăng nhập");
    }
};

// Lấy danh sách người dùng
export const getAllUsers = async (req, res) => {
    try {
        const users = await User.find();
        res.render("users", { title: "Danh Sách Người Dùng", users });
    } catch (error) {
        res.status(500).send("Lỗi lấy danh sách người dùng");
    }
};
