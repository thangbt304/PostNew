exports.getHome = (req, res) => {
    res.sendFile(__dirname + "/../../views/home");
};

exports.getAbout = (req, res) => {
    res.sendFile(__dirname + "/../../views/about");
};
