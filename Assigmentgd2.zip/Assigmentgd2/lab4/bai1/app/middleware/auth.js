import jwt from 'jsonwebtoken';

const authMiddleware = (req, res, next) => {
    const token = req.cookies?.token; // Lấy token từ cookie
    if (!token) {
        res.locals.user = null;
        return next();
    }

    try {
        const decoded = jwt.verify(token, 'secret'); // Giải mã token
        req.userId = decoded.id;  // Lưu userId vào req
        res.locals.user = decoded; // Lưu user vào res.locals để dùng trong template
        next();
    } catch (error) {
        res.locals.user = null;
        next();
    }
};

export default authMiddleware;
