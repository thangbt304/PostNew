import crypto from "crypto";

// Mã hóa mật khẩu bằng SHA-256 với salt cố định
export const hashPassword = (password) => {
    const salt = "mySecretSalt"; // ✅ Thêm chuỗi salt cố định
    return crypto.createHash("sha256").update(password + salt).digest("hex");
};

// So sánh mật khẩu nhập vào với mật khẩu đã mã hóa
export const comparePassword = (inputPassword, hashedPassword) => {
    return hashPassword(inputPassword) === hashedPassword;
};
