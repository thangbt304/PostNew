import mongoose from "mongoose";
import dotenv from "dotenv";
import connectDB from "./config/db.js";
import Post from "./models/Post.js"; // Thay thế bằng model của bạn nếu cần

dotenv.config();
connectDB();

const seedData = async () => {
  try {
    // Xóa toàn bộ dữ liệu cũ trong collection "posts"
    await Post.deleteMany();

    // Chèn dữ liệu mẫu
    const posts = [
      { title: "Bài viết 1", content: "Nội dung bài viết 1" },
      { title: "Bài viết 2", content: "Nội dung bài viết 2" },
      { title: "Bài viết 3", content: "Nội dung bài viết 3" },
    ];

    await Post.insertMany(posts);
    console.log("✅ Dữ liệu đã được chèn thành công!");
    process.exit();
  } catch (error) {
    console.error("❌ Lỗi khi chèn dữ liệu:", error);
    process.exit(1);
  }
};

// Gọi hàm seedData
seedData();
